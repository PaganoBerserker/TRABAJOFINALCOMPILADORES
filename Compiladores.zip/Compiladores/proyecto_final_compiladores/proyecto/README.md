Integrantes del equipo:
	=>Cabrera Lopez Oscar Emilio
	=>Flores Gaspar Juan Antonio
	=>Salazar Santiago Juan Carlos

Para compilar ejecute:

```
$ flex lexer.l
$ gcc -Wall main.c
```

Para probar el programa ejecute:

```
$ ./a.out archivo_prueba
```

Se mostrara el desarrollo del algoritmo
